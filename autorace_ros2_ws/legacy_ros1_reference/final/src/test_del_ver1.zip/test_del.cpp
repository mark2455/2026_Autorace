//4and

#include <ros/ros.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <sensor_msgs/PointCloud2.h>
#include <std_msgs/Float64.h>
#include <cmath>

ros::Publisher steering_pub;
std_msgs::Float64 steering_msg;
double steering_angle = 0.0;

// Distance threshold to start avoiding obstacles
double distance_threshold = 0.5; // Set your desired distance threshold here

// Steering control limits
double steering_limit = 0.5;
double straight_steering = 0.0;

// Function to limit the steering control within the specified range
double limitSteering(double steering)
{
  if (steering > steering_limit)
    return steering_limit;
  else if (steering < -steering_limit)
    return -steering_limit;
  else
    return steering;
}

void obstacleLeftCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
{
  pcl::PointCloud<pcl::PointXYZ> obstacle_cloud;
  pcl::fromROSMsg(*msg, obstacle_cloud);

  // Calculate the average distance from the origin to the obstacle points
  double avg_distance = 0.0;
  for (int i = 0; i < obstacle_cloud.size(); ++i) {
    double distance = std::sqrt(std::pow(obstacle_cloud.points[i].x, 2) + std::pow(obstacle_cloud.points[i].y, 2));
    avg_distance += distance;
  }
  avg_distance /= obstacle_cloud.size();

  // Calculate the steering angle based on the distance to the obstacle
  double steering_angle = 0.0;
  if (avg_distance < distance_threshold) {
    // If the distance is below the threshold, steer away from the obstacle
    steering_angle = std::atan2(obstacle_cloud.points[0].y, obstacle_cloud.points[0].x);
  }
  else {
    steering_angle = 0.0;
  }

  // Limit the steering control within the specified range
  steering_angle = limitSteering(steering_angle);

  // Publish the steering angle
  steering_msg.data = steering_angle;
  steering_pub.publish(steering_msg);
}

void obstacleRightCallback(const sensor_msgs::PointCloud2::ConstPtr& msg)
{
  pcl::PointCloud<pcl::PointXYZ> obstacle_cloud;
  pcl::fromROSMsg(*msg, obstacle_cloud);

  // Calculate the average distance from the origin to the obstacle points
  double avg_distance = 0.0;
  for (int i = 0; i < obstacle_cloud.size(); ++i) {
    double distance = std::sqrt(std::pow(obstacle_cloud.points[i].x, 2) + std::pow(obstacle_cloud.points[i].y, 2));
    avg_distance += distance;
  }
  avg_distance /= obstacle_cloud.size();

  // Calculate the steering angle based on the distance to the obstacle
  if (avg_distance < distance_threshold) {
    // If the distance is below the threshold, steer away from the obstacle
    steering_angle = std::atan2(-obstacle_cloud.points[0].y, -obstacle_cloud.points[0].x);
  }
  else {
  steering_angle = 0.0;
  }

  // Limit the steering control within the specified range
  steering_angle = limitSteering(steering_angle);
  
  steering_angle = -steering_angle;

  // Publish the steering angle
  steering_msg.data = steering_angle;
  steering_pub.publish(steering_msg);
}



int main(int argc, char** argv)
{
  ros::init(argc, argv, "test_del");
  ros::NodeHandle nh;

  ros::Subscriber obstacle_left_sub = nh.subscribe<sensor_msgs::PointCloud2>("/filter_L", 10, obstacleLeftCallback);
  ros::Subscriber obstacle_right_sub = nh.subscribe<sensor_msgs::PointCloud2>("/filter_R", 10, obstacleRightCallback);
  steering_pub = nh.advertise<std_msgs::Float64>("/del", 10);

  ros::spin();

  return 0;
}
